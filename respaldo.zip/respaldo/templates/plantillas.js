module.exports = {
    registrocc : `<table data-module="notification_default_icon" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/thumbnails/169.png" data-visible="false" class="email_section" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                    <tr>
                      <td class="email_bg bg_light px py_lg" data-bgcolor="Light" style="font-size: 0;text-align: center;line-height: 100%;background-color: #d1deec;padding-top: 64px;padding-bottom: 64px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                        <!--[if (mso)|(IE)]>
                        <table role="presentation" width="800" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                          <tbody>
                          <tr>
                            <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                        <![endif]-->
                        <div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><table class="content_section ui-resizable" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width: 800px;margin: 0 auto;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                        <tbody>
                        <tr>
                          <td class="content_cell bg_white brounded bt_primary px py_md" data-bgcolor="White" data-border-top-color="Border Primary" style="font-size: 0;text-align: center;background-color: #ffffff;border-top: 4px solid #EA5455;border-radius: 4px;padding-top: 32px;padding-bottom: 32px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="624" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td width="208" align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <div class="col_1" style="vertical-align: top;display: inline-block;width: 100%;max-width: 208px;">
                                <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                  <tbody>
                                  <tr>
                                    <td class="column_cell px py_xs text_primary text_left mobile_center" data-color="Primary" style="vertical-align: top;color: #2376dc;text-align: left;padding-top: 8px;padding-bottom: 8px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                      <p class="img_inline" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 16px;line-height: 100%;clear: both;"><a href="https://facilcontabilidad.org:3001/" data-color="Primary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #2376dc;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="https://juassic.com/castor.png" width="220" height="" alt="CastorX website" style="max-width: 110px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a></p>
                                    </td>
                                  </tr>
                                  </tbody>
                                </table>
                              </div>
                              <!--[if (mso)|(IE)]>
                              </td>
                              <td width="416" align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <div class="col_3" style="vertical-align: top;display: inline-block;width: 100%;max-width: 416px;">
                                <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                  <tbody>
                                  <tr>
                                    <td class="column_cell px py_xs text_right mobile_center" style="vertical-align: top;text-align: right;padding-top: 8px;padding-bottom: 8px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                      <!-- <p class="text_secondary" data-color="Secondary" style="color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 16px;line-height: 26px;"><a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Shop</span></a> &nbsp; × &nbsp; <a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Resources</span></a> &nbsp; × &nbsp; <a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Help</span></a></p> -->
                                    </td>
                                  </tr>
                                  </tbody>
                                </table>
                              </div>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="416" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <div class="col_3" style="vertical-align: top;display: inline-block;width: 100%;max-width: 416px;">
                                <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                  <tbody>
                                  <tr>
                                    <td class="column_cell bb_light" height="32" data-border-bottom-color="Border Light" style="vertical-align: top;border-bottom: 1px solid #dee0e1;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">&nbsp;</td>
                                  </tr>
                                  </tbody>
                                </table>
                              </div>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="624" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                <tbody>
                                <tr>
                                  <td class="column_cell px py_md text_dark text_center" data-color="Dark" style="vertical-align: top;color: #333333;text-align: center;padding-top: 32px;padding-bottom: 32px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                    <table class="column column_inline" role="presentation" align="center" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;width: auto;margin: 0 auto;clear: both;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                      <tbody>
                                      <tr>
                                        <td class="column_cell bg_primary brounded_circle px py text_white text_center" data-bgcolor="Primary" data-color="White" style="vertical-align: top;background-color: #ea5455; color: #ffffff; border-radius: 50%; text-align: center;padding-top: 16px;padding-bottom: 16px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                          <p class="img_full" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 0 !important;line-height: 100%;clear: both;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/check_white.png" width="48" height="48" alt="" style="max-width: 48px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;display: block;width: 100%;margin: 0px auto;"></p>
                                        </td>
                                      </tr>
                                      </tbody>
                                    </table>
                                    <h2 class="mt mb_xs" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 16px;margin-bottom: 8px;word-break: break-word;font-size: 28px;line-height: 38px;font-weight: bold;">Registro Correcto</h2>
                                    <p class="text_lead text_secondary mb_md" data-color="Secondary" style="color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 32px;word-break: break-word;font-size: 19px;line-height: 31px;">Te has registrado correctamente en Castor X</p>
                                    <p class="mb_md" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 32px;word-break: break-word;font-size: 16px;line-height: 26px;">Tu cuenta se encuentra activa y lista para ser usada.<br/>Ya puedes desatar el poder de CastorX en las descargas masivas de documentos del SRI de la forma mas sencilla jamas vista, tienes acceso a tu CastorDrive para que almacenes tus documentos hasta que los haya procesado o hasta que dejen de ser utiles, y si llegas a alcanzar el máximo de almacenamiento, siempre tendrás opciones de actualizar a una cuenta con mas capacidad</p>
                                    <table role="presentation" class="ebutton" align="center" border="0" cellspacing="0" cellpadding="0" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;margin: 0 auto;">
                                      <tbody>
                                      <tr>
                                        <td class="bg_primary" data-bgcolor="Primary" style="background-color: #ea5455;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;font-size: 16px;padding: 13px 24px;border-radius: 4px;line-height: normal;text-align: center;font-weight: bold;-webkit-transition: box-shadow .25s;transition: box-shadow .25s;"><a href="https://facilcontabilidad.org:3001/" data-color="White" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #ffffff;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-weight: bold;"><span data-color="White" style="color: #ffffff;text-decoration: none;">Ingresa a Castor X</span></a></td>
                                      </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                                </tbody>
                              </table>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="content_cell" style="font-size: 0;text-align: center;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="624" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                <tbody>
                                <tr>
                                  <td class="column_cell px py_md text_secondary text_center" data-color="Secondary" style="vertical-align: top;color: #959ba0;text-align: center;padding-top: 32px;padding-bottom: 32px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                    <p class="img_inline mb" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 16px;word-break: break-word;font-size: 16px;line-height: 100%;clear: both;">
                                      <a href="https://www.facebook.com/facilcontabilidad" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/facebook.png" width="24" height="24" alt="Facebook" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a> &nbsp;&nbsp;
                                      <a href="https://t.me/facilcontabilidad" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="https://lh3.googleusercontent.com/Zmol9WVk6mjWE38P6wc3Aaz9mQn-VFhviKllLP4kiplfW4xIEjgYmKUalZcFsOOnDQ" width="24" height="24" alt="Telegran" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a> &nbsp;&nbsp;
                                      <a href="https://instagram.com/fcontabilidad" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/instagram.png" width="24" height="24" alt="Instagram" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a> &nbsp;&nbsp;
                                      <a href="https://www.youtube.com/channel/UCNrL5emDrA-RmifWsbBhv3g?view_as=subscriber" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/youtube.png" width="24" height="24" alt="Youtube" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a>
                                    </p>
                                    <p class="mb_xs" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 8px;word-break: break-word;font-size: 16px;line-height: 26px;">©2020 Rowilled. <a class="text_adr" href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Carlos Ibarra 176 y 10 de Agosto, Edifcio Yuraj Pirca</span></a></p>
                                    <p class="text_link text_xs" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 14px;line-height: 22px;">Recibes este email como respuesta a una interacción con CastorX. <a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: underline;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">No deseo recibir</span></a></p>
                                  </td>
                                </tr>
                                </tbody>
                              </table>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                          </td>
                        </tr>
                        </tbody>
                      </table>
                        <!--[if (mso)|(IE)]>
                        </td>
                        </tr>
                        </tbody>
                        </table>
                        <![endif]-->
                      </td>
                    </tr>
                    </tbody>
                  </table>`,



    registrotransfer : `<table data-module="notification_default_icon" data-thumb="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/thumbnails/169.png" data-visible="false" class="email_section" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                    <tr>
                      <td class="email_bg bg_light px py_lg" data-bgcolor="Light" style="font-size: 0;text-align: center;line-height: 100%;background-color: #d1deec;padding-top: 64px;padding-bottom: 64px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                        <!--[if (mso)|(IE)]>
                        <table role="presentation" width="800" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                          <tbody>
                          <tr>
                            <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                        <![endif]-->
                        <div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><table class="content_section ui-resizable" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width: 800px;margin: 0 auto;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                        <tbody>
                        <tr>
                          <td class="content_cell bg_white brounded bt_primary px py_md" data-bgcolor="White" data-border-top-color="Border Primary" style="font-size: 0;text-align: center;background-color: #ffffff;border-top: 4px solid #EA5455;border-radius: 4px;padding-top: 32px;padding-bottom: 32px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="624" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td width="208" align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <div class="col_1" style="vertical-align: top;display: inline-block;width: 100%;max-width: 208px;">
                                <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                  <tbody>
                                  <tr>
                                    <td class="column_cell px py_xs text_primary text_left mobile_center" data-color="Primary" style="vertical-align: top;color: #2376dc;text-align: left;padding-top: 8px;padding-bottom: 8px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                      <p class="img_inline" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 16px;line-height: 100%;clear: both;"><a href="https://facilcontabilidad.org:3001/" data-color="Primary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #ea5455;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="https://juassic.com/castor.png" width="220" height="" alt="CastorX website" style="max-width: 110px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a></p>
                                    </td>
                                  </tr>
                                  </tbody>
                                </table>
                              </div>
                              <!--[if (mso)|(IE)]>
                              </td>
                              <td width="416" align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <div class="col_3" style="vertical-align: top;display: inline-block;width: 100%;max-width: 416px;">
                                <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                  <tbody>
                                  <tr>
                                    <td class="column_cell px py_xs text_right mobile_center" style="vertical-align: top;text-align: right;padding-top: 8px;padding-bottom: 8px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                      <!-- <p class="text_secondary" data-color="Secondary" style="color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 16px;line-height: 26px;"><a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Shop</span></a> &nbsp; × &nbsp; <a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Resources</span></a> &nbsp; × &nbsp; <a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Help</span></a></p> -->
                                    </td>
                                  </tr>
                                  </tbody>
                                </table>
                              </div>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="416" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <div class="col_3" style="vertical-align: top;display: inline-block;width: 100%;max-width: 416px;">
                                <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                  <tbody>
                                  <tr>
                                    <td class="column_cell bb_light" height="32" data-border-bottom-color="Border Light" style="vertical-align: top;border-bottom: 1px solid #dee0e1;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">&nbsp;</td>
                                  </tr>
                                  </tbody>
                                </table>
                              </div>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="624" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                <tbody>
                                <tr>
                                  <td class="column_cell px py_md text_dark text_center" data-color="Dark" style="vertical-align: top;color: #333333;text-align: center;padding-top: 32px;padding-bottom: 32px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                    <table class="column column_inline" role="presentation" align="center" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;width: auto;margin: 0 auto;clear: both;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                      <tbody>
                                      <tr>
                                        <td class="column_cell bg_primary brounded_circle px py text_white text_center" data-bgcolor="Primary" data-color="White" style="vertical-align: top;background-color: #ea5455; color: #ffffff; border-radius: 50%; text-align: center;padding-top: 16px;padding-bottom: 16px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                          <p class="img_full" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 0 !important;line-height: 100%;clear: both;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/check_white.png" width="48" height="48" alt="" style="max-width: 48px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;display: block;width: 100%;margin: 0px auto;"></p>
                                        </td>
                                      </tr>
                                      </tbody>
                                    </table>
                                    <h2 class="mt mb_xs" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 16px;margin-bottom: 8px;word-break: break-word;font-size: 28px;line-height: 38px;font-weight: bold;">Registro Correcto</h2>
                                    <p class="text_lead text_secondary mb_md" data-color="Secondary" style="color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 32px;word-break: break-word;font-size: 19px;line-height: 31px;">Te has registrado correctamente en Castor X</p>
                                    <p class="mb_md" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 32px;word-break: break-word;font-size: 16px;line-height: 26px;">Gracias por registrarte en CastorX, te informamos que por ahora tu cuenta se encuentra temporalmente inactiva hasta tanto se verifique que los datos de registro y de pago  que ingresaste son correctos.<br/>Una vez verificado, se procedera a activar tu cuenta y se te enviará una notificación a tu email.<br/>Ya con tu cuenta activada podrás desatar el poder de CastorX en las descargas masivas de documentos del SRI de la forma mas sencilla jamas vista, tienes acceso a tu CastorDrive para que almacenes tus documentos hasta que los haya procesado o hasta que dejen de ser utiles, y si llegas a alcanzar el máximo de almacenamiento, siempre tendrás opciones de actualizar a una cuenta con mas capacidad</p>
                                    <table role="presentation" class="ebutton" align="center" border="0" cellspacing="0" cellpadding="0" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;margin: 0 auto;">
                                      <tbody>
                                      <tr>
                                        <td class="bg_primary" data-bgcolor="Primary" style="background-color: #ea5455;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;font-size: 16px;padding: 13px 24px;border-radius: 4px;line-height: normal;text-align: center;font-weight: bold;-webkit-transition: box-shadow .25s;transition: box-shadow .25s;"><a href="https://facilcontabilidad.org:3001/" data-color="White" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #ffffff;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-weight: bold;"><span data-color="White" style="color: #ffffff;text-decoration: none;">Ingresa a Castor X</span></a></td>
                                      </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                                </tbody>
                              </table>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="content_cell" style="font-size: 0;text-align: center;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                            <div class="column_row" style="font-size: 0;text-align: center;max-width: 624px;margin: 0 auto;">
                              <!--[if (mso)|(IE)]>
                              <table role="presentation" width="624" border="0" cellspacing="0" cellpadding="0" align="center" style="vertical-align:top;Margin:0 auto;">
                                <tbody>
                                <tr>
                                  <td align="center" style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;vertical-align:top;">
                              <![endif]-->
                              <table class="column" role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" border="0" style="vertical-align: top;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                <tbody>
                                <tr>
                                  <td class="column_cell px py_md text_secondary text_center" data-color="Secondary" style="vertical-align: top;color: #959ba0;text-align: center;padding-top: 32px;padding-bottom: 32px;padding-left: 16px;padding-right: 16px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                                    <p class="img_inline mb" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 16px;word-break: break-word;font-size: 16px;line-height: 100%;clear: both;">
                                      <a href="https://www.facebook.com/facilcontabilidad" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/facebook.png" width="24" height="24" alt="Facebook" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a> &nbsp;&nbsp;
                                      <a href="https://t.me/facilcontabilidad" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="https://lh3.googleusercontent.com/Zmol9WVk6mjWE38P6wc3Aaz9mQn-VFhviKllLP4kiplfW4xIEjgYmKUalZcFsOOnDQ" width="24" height="24" alt="Telegran" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a> &nbsp;&nbsp;
                                      <a href="https://instagram.com/fcontabilidad" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/instagram.png" width="24" height="24" alt="Instagram" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a> &nbsp;&nbsp;
                                      <a href="https://www.youtube.com/channel/UCNrL5emDrA-RmifWsbBhv3g?view_as=subscriber" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><img src="http://www.stampready.net/dashboard/editor/user_uploads/zip_uploads/2017/10/16/4pId6zuQoxceDO0FnBKAPq38/notifications/images/youtube.png" width="24" height="24" alt="Youtube" style="max-width: 24px;-ms-interpolation-mode: bicubic;border: 0;height: auto;line-height: 100%;outline: none;text-decoration: none;"></a>
                                    </p>
                                    <p class="mb_xs" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 8px;word-break: break-word;font-size: 16px;line-height: 26px;">©2020 Rowilled. <a class="text_adr" href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: none;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">Carlos Ibarra 176 y 10 de Agosto, Edifcio Yuraj Pirca</span></a></p>
                                    <p class="text_link text_xs" style="color: inherit;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;font-size: 14px;line-height: 22px;">Recibes este email como respuesta a una interacción con CastorX. <a href="#" data-color="Secondary" style="-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-decoration: underline;color: #959ba0;font-family: Arial, Helvetica, sans-serif;margin-top: 0px;margin-bottom: 0px;word-break: break-word;"><span data-color="Secondary" style="color: #959ba0;text-decoration: none;">No deseo recibir</span></a></p>
                                  </td>
                                </tr>
                                </tbody>
                              </table>
                              <!--[if (mso)|(IE)]>
                              </td>
                              </tr>
                              </tbody>
                              </table>
                              <![endif]-->
                            </div>
                          </td>
                        </tr>
                        </tbody>
                      </table>
                        <!--[if (mso)|(IE)]>
                        </td>
                        </tr>
                        </tbody>
                        </table>
                        <![endif]-->
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </div>`


}