

module.exports = (app) => {
    return  require("./plantillas.js")
}