define({
    fr: {
        'Allowed values:'             : 'Valeurs autorisées :',
        'Compare all with predecessor': 'Tout comparer avec ...',
        'compare changes to:'         : 'comparer les changements à :',
        'compared to'                 : 'comparer à',
        'Default value:'              : 'Valeur par défaut :',
        'Description'                 : 'Description',
        'Field'                       : 'Champ',
        'General'                     : 'Général',
        'Generated with'              : 'Généré avec',
        'Name'                        : 'Nom',
        'No response values.'         : 'Aucune valeur de réponse.',
        'optional'                    : 'optionnel',
        'Parameter'                   : 'Paramètre',
        'Permission:'                 : 'Permission :',
        'Response'                    : 'Réponse',
        'Send'                        : 'Envoyer',
        'Send a Sample Request'       : 'Envoyer une requête représentative',
        'show up to version:'         : 'Montrer à partir de la version :',
        'Size range:'                 : 'Ordre de grandeur :',
        'Type'                        : 'Type',
        'url'                         : 'url'
    }
});
