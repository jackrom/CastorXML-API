module.exports = {

    TOKEN_KEY: 'Millonario*Fc*2014*',
    EMAIL_HOST: 'smtp.elasticemail.com',
    EMAIL_PORT: 2525,
    EMAIL_USER: 'info@facilcontabilidad.com',
    EMAIL_PASSWORD: 'CC9800D31C6435095E42E5BEA7CC710B4191',
    EMAIL_LINK: 'https://facilcontabilidad.org/#/'
    /*
    TOKEN_KEY: 'Millonario*Fc*2014*',
    EMAIL_HOST: 'juassic.com',
    EMAIL_PORT: 465,
    EMAIL_USER: 'info@juassic.com',
    EMAIL_PASSWORD: '6662115JcRc',
    EMAIL_LINK: 'https://facilcontabilidad.org/#/'
    */
}